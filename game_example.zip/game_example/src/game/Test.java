package game;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] scores = new int[10];
		int[] skills = {5,8,7,2,3,2,7,6,9,1};
		Team2 blue = new Team2(skills, 500);
		blue.campain(400);
		double pop = blue.getpopularity();
		System.out.println(pop);

	}

}
