package game;

import java.lang.reflect.Array;

public class Team2 {
	private int[] players= new int[10];
	private int popularity = 0;
	private double funds;
	private int wins = 0;
	private int losses = 0;
	
	//insert private varibles, we should have some players. skill scores for each player, popularity, funds, wins and losses
	public Team2(int[] skills, double funds) {
		this.funds = funds;
		players = skills;
	}
		
		//create public method replace player, takes an interger for array position and skill score, then updates. will terminate if positon is larger than 5, will allow max 10 skill
	public void replaceplayer(int index, int skill) {
		Array.set(players, index, Math.min(skill, 10));
	}
		
		//public method method update wins/losses. wins if postive, losses if negtive
	public void winlose(int value) {
		wins = wins + Math.max(0, value/Math.abs(value));
		losses = losses + Math.max(0, -value/Math.abs(value));
	}
		
	public void updatefunds(double amount) {
		funds = funds + amount;
	}
	
	public void updatepopularity(int amount) {
		popularity = popularity + amount;
	}
	
	public void campain(int amount) {
		funds = funds - Math.min(funds, amount);
		popularity = popularity + (int) Math.min(funds, amount)/100;
	}
		
	public int getpopularity() {
		return popularity;
	}
	
	public int getskill(int index) {
		return Array.getInt(players, index);
	}
}
