package game;

public class Team {
	
	//insert private varibles, we should have some players. skill scores for each player, popularity, funds, wins and losses
	private int player1;
	
	private int player2;
	
	private int player3;
	
	private int popularity = 0;
	
	private int funds;
	
	private int wins = 0;
	
	private int losses = 0;
	
	
	//constructs a team team
	public Team(int player1, int player2, int player3, int funds) {
		this.player1 = Math.min(10, player1);
		this.player2 = Math.min(10, player2);
		this.player3 = Math.min(10, player3);
		this.funds = funds;
	}
	
	
	//public replace player 1. sets players 1 int to new integer max 10
	public void replace1(int skill) {
		player1 = Math.min(10, skill);
	}
	
	public void replace2(int skill) {
		player2 = Math.min(10, skill);
	}
	
	public void replace3(int skill) {
		player3 = Math.min(10, skill);
	}
	
	public void winlose(int score) {
		wins = wins + Math.max(score/score, 0);
		losses = losses + Math.max(-score/score, 0);
	}
	
	public void updatefunds(int amount) {
		funds = funds + amount;
	}
	
	//public update populirty, adds this int to popularity
	
	public void updatepopularity(int pop) {
		popularity = popularity + pop;
	}
	
	public void campain(int amount) {
	funds = funds - Math.min(funds, amount);
	popularity = popularity + Math.min(funds, amount)/100;
	}
	
	public int pop() {
		return popularity;
	}
	
	//public get player 1, retuns players skill
	public int getp1() {
		return player1;
	}
	
	public int getp2() {
		return player2;
	}
	
	public int getp3() {
		return player3;
	}
}

