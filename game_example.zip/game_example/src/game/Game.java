package game;

public class Game {

	//insert private varibles, score team 1, score team 2, team 1 and team 2
	private int homescore = 0;
	private int awayscore = 0;
	private Team home;
	private Team away;
	
	public Game(Team one, Team two) {
		home = one;
		away = two;
	}
	
	public void simulate() {
		home.updatefunds(home.pop()*50);
		away.updatefunds(away.pop()*50);
		
	}
	//public static game. takes in two teams and simulates a game, returns the winning team
	//game will increase a teams funds by 50*popularity for each team
	//games are three rounds
	//if score is same at end home will gain one point
	//popularity will increase by 5 for winning team and decrease by 1 for lossing team
	

	private void roundone() {
	}
	//private helper method round with input number round
	//genrates a random number between 1 and 15 for player on home team then selects the min between skill and rand number
	//adds this to away team score//genrates a random number between 1 and 14 for player on home team then selects the min between skill and rand number
	//adds this to home team score
	
	}
