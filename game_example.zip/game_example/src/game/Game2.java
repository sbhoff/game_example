package game;

import java.util.Random;

public class Game2 {
	//insert private varibles, score team 1, score team 2, team 1 and team 2
	private int homescore = 0;
	private int awayscore = 0;
	private Team2 home;
	private Team2 away;
	
	public Game2(Team2 home, Team2 away) {
		this.home = home;
		this.away = away;
	}
	
	public Team2 simulate() {
		home.updatefunds(home.getpopularity()*50);
		away.updatefunds(away.getpopularity()*50);
		round();
		round();
		round();
		round();
		if(homescore == awayscore) {
			homescore++;
		}
		
		if(homescore > awayscore) {
			home.updatepopularity(5);
			away.updatepopularity(-1);
			return home;
		} else {
			away.updatepopularity(5);
			home.updatepopularity(-1);
			return away;
		}
	}

	private void round() {
		Random rand = new Random();
		homescore = homescore + Math.min(home.getskill(rand.nextInt(10)), rand.nextInt(15));
		awayscore = awayscore + Math.min(away.getskill(rand.nextInt(10)), rand.nextInt(14));
	}

}
